/******************************************************************************
 * echo_server.c                                                               *
 *                                                                             *
 * Description: This file contains the C source code for an echo server.  The  *
 *              server runs on a hard-coded port and simply write back anything*
 *              sent to it by connected clients.  It does not support          *
 *              concurrent clients.                                            *
 *                                                                             *
 * Authors: Athula Balachandran <abalacha@cs.cmu.edu>,                         *
 *          Wolf Richter <wolf@cs.cmu.edu>                                     *
 *                                                                             *
 *******************************************************************************/

#include <netinet/in.h>
#include <netinet/ip.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <unistd.h>
#include <parse.h>
#include <time.h>
#include <errno.h>
#include <arpa/inet.h>

FILE *accesslog;
FILE *errorlog;
#define ECHO_PORT 9999
#define BUF_SIZE 8192
struct sockaddr_in addr, cli_addr;

void write_errorlog(struct sockaddr_in addr, char *error)
{
    time_t curtime;
    time(&curtime);
    char *timenow = ctime(&curtime);
    fprintf(errorlog, "[%s][error][client %s %d]%s", timenow, inet_ntoa(addr.sin_addr), ntohs(addr.sin_port), error);
}
void write_accesslog(struct sockaddr_in addr, int code, Request *request)
{

    time_t curtime;
    time(&curtime);
    char *timenow = ctime(&curtime);
    if (request == NULL)
    {
        fprintf(accesslog, "%s--[%s]\"---\"%d",
                inet_ntoa(addr.sin_addr), timenow, code);
        return;
    }
    fprintf(accesslog, "%s--[%s]\"%s %s %s\"%d",
            inet_ntoa(addr.sin_addr), timenow, request->http_method, request->http_uri, request->http_version, code);
}
int close_socket(int sock)
{
    if (close(sock))
    {
        fprintf(stderr, "Failed closing socket.\n");
        write_errorlog(addr, strerror(errno));
        return 1;
    }
    return 0;
}
void init_log()
{
    errorlog = fopen("/home/project-1/log/errorlog", "w");
    accesslog = fopen("/home/project-1/log/accesslog", "w");
    if (!errorlog || !accesslog) {
        fprintf(stderr, "Error opening log file.\n");
        return 1;
    }
    return 0;
}
void get_filetype(char *filename, char *filetype)
{
    if (strstr(filename, ".html"))
        strcpy(filetype, "text/html");
    else if (strstr(filename, ".gif"))
        strcpy(filetype, "image/gif");
    else if (strstr(filename, ".png"))
        strcpy(filetype, "image/png");
    else if (strstr(filename, ".css"))
        strcpy(filetype, "text/css");
    else if (strstr(filename, ".jpg") || strstr(filename, ".jpeg"))
        strcpy(filetype, "image/jpeg");
    else
        strcpy(filetype, "text/plain");
}
int send_message(int client_socket, char *buf, int length){
    int readret;
    if ((readret = send(client_socket, buf, length, 0)) != length) {
        close_socket(client_socket);
        fprintf(stderr, "Error sending to client.\n");
        write_errorlog(addr, strerror(errno));
        return;
    }
    return readret;
}
void response(char *buf, int readret, Request *a, int sock, int client_sock)
{
    struct stat fbuf;
    char filename[8192];
    char filetype[32];
    char filetime[32];
    memset(filename, 0, 8192);
    sprintf(filename, "static_site%s", a->http_uri);
    if (stat(filename, &fbuf) == -1)
    {
        memset(buf, 0, BUF_SIZE);
        strcpy(buf, "HTTP/1.1 404 Not Found\r\n\r\n");
        readret = strlen(buf);
        write_accesslog(addr, 404, a);
        if (send(client_sock, buf, readret, 0) != readret)
        {
            close_socket(client_sock);
            close_socket(sock);
            fprintf(stderr, "Error sending to client.\n");
            write_errorlog(addr, strerror(errno));
            return;
        }
        memset(buf, 0, BUF_SIZE);
        return;
    }
    if (S_ISDIR(fbuf.st_mode))
    {
        strcat(filename, "index.html");
    }
    if (stat(filename, &fbuf) == -1)
    {
        memset(buf, 0, BUF_SIZE);
        strcpy(buf, "HTTP/1.1 404 Not Found\r\n\r\n");
        readret = strlen(buf);
        write_accesslog(addr, 404, a);
        if (send(client_sock, buf, readret, 0) != readret)
        {
            close_socket(client_sock);
            close_socket(sock);
            fprintf(stderr, "Error sending to client.\n");
            write_errorlog(addr, strerror(errno));
            return;
        }
        memset(buf, 0, BUF_SIZE);
        return;
    }
    get_filetype(filename, filetype);
    memset(buf, 0, BUF_SIZE);
    strcpy(buf, "HTTP/1.1 200 OK\r\n");
    strcat(buf, "Connection: keep-alive\r\n");
    time_t curtime = time(NULL);
    char timenow[32];
    char temp[64];
    strftime(timenow, sizeof(timenow), "%a, %d %b %Y %H:%M:%S %Z", gmtime(&curtime));
    sprintf(temp, "Date: %s\r\n", timenow);
    strcat(buf, temp);
    strcat(buf, "Server: liso/1.0\r\n");
    strftime(filetime, sizeof(timenow), "%a, %d %b %Y %H:%M:%S %Z", gmtime(&(fbuf.st_mtime)));
    sprintf(temp, "Last-Modified: %s\r\n", filetime);
    strcat(buf, temp);
    sprintf(temp, "Content-Length: %ld\r\n", fbuf.st_size);
    strcat(buf, temp);
    sprintf(temp, "Content-Type: %s\r\n", filetype);
    strcat(buf, temp);
    strcat(buf, "\r\n");
    if (!strcmp(a->http_method, "HEAD"))
    {
        readret = strlen(buf);
        if (send(client_sock, buf, readret, 0) != readret)
        {
            close_socket(client_sock);
            close_socket(sock);
            fprintf(stderr, "Error sending to client.\n");
            write_errorlog(addr, strerror(errno));
            return;
        }
        memset(buf, 0, BUF_SIZE);
    }
    if (!strcmp(a->http_method, "GET"))
    {
        if (access(filename, R_OK) == -1)
        {
            memset(buf, 0, BUF_SIZE);
            strcpy(buf, "HTTP/1.1 403 Forbidden\r\n\r\n");
            readret = strlen(buf);
            write_accesslog(addr, 403, a);
            if (send(client_sock, buf, readret, 0) != readret)
            {
                close_socket(client_sock);
                close_socket(sock);
                fprintf(stderr, "Error sending to client.\n");
                write_errorlog(addr, strerror(errno));
                return;
            }
            memset(buf, 0, BUF_SIZE);
            return;
        }
        FILE *file = fopen(filename, "rb");
        if (file == NULL)
        {
            fprintf(stderr, "error open file\n");
            write_errorlog(addr, strerror(errno));
            close_socket(sock);
            return;
        }
        int fsize = fbuf.st_size + strlen(buf);
        char buffer[BUF_SIZE];
        if (fbuf.st_size + strlen(buf) <= BUF_SIZE)
        {
            fread(buffer, sizeof(char), fbuf.st_size, file);
            strcat(buf, buffer);
            readret = strlen(buf);
            if (send(client_sock, buf, readret, 0) != readret)
            {
                close_socket(client_sock);
                close_socket(sock);
                fprintf(stderr, "Error sending to client.\n");
                write_errorlog(addr, strerror(errno));
                return;
            }
            return;
        }
        if (fbuf.st_size + strlen(buf) > BUF_SIZE)
        {
            fread(buffer, sizeof(char), BUF_SIZE - strlen(buf), file);
            strcat(buf, buffer);
            readret = BUF_SIZE;
            if (send(client_sock, buf, readret, 0) != readret)
            {
                close_socket(client_sock);
                close_socket(sock);
                fprintf(stderr, "Error sending to client.\n");
                write_errorlog(addr, strerror(errno));
                return ;
            }
            fsize = fsize - BUF_SIZE;
        }
        while (fsize > BUF_SIZE)
        {
            fread(buf, sizeof(char), BUF_SIZE, file);
            readret = BUF_SIZE;
            if (send(client_sock, buf, readret, 0) != readret)
            {
                close_socket(client_sock);
                close_socket(sock);
                fprintf(stderr, "Error sending to client.\n");
                write_errorlog(addr, strerror(errno));
                return ;
            }
            fsize = fsize - BUF_SIZE;
        }
        fread(buf, sizeof(char), fsize, file);
        readret = strlen(buf);
        if (send(client_sock, buf, readret, 0) != readret)
        {
            close_socket(client_sock);
            close_socket(sock);
            fprintf(stderr, "Error sending to client.\n");
            write_errorlog(addr, strerror(errno));
            return ;
        }
        write_accesslog(addr, 200, a);
    }
}

int main(int argc, char *argv[])
{
    int sock, client_sock;
    ssize_t readret;
    socklen_t cli_size;
    char buf[BUF_SIZE];
    fprintf(stdout, "----- Echo Server -----\n");
    init_log();

    /* all networked programs must create a socket */
    if ((sock = socket(PF_INET, SOCK_STREAM, 0)) == -1)
    {
        fprintf(stderr, "Failed creating socket.\n");
        write_errorlog(addr, strerror(errno));
        return EXIT_FAILURE;
    }
    int reuse = 1;
    if (setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse)) == -1)
    {
        printf("Setsockopt error.\n");
        return 1;
    }
    addr.sin_family = AF_INET;
    addr.sin_port = htons(ECHO_PORT);
    addr.sin_addr.s_addr = INADDR_ANY;

    /* servers bind sockets to ports---notify the OS they accept connections */
    if (bind(sock, (struct sockaddr *)&addr, sizeof(addr)))
    {
        close_socket(sock);
        fprintf(stderr, "Failed binding socket.\n");
        write_errorlog(addr, strerror(errno));
        return EXIT_FAILURE;
    }

    if (listen(sock, 5))
    {
        close_socket(sock);
        fprintf(stderr, "Error listening on socket.\n");
        write_errorlog(addr, strerror(errno));
        return EXIT_FAILURE;
    }

    /* finally, loop waiting for input and then write it back */
    while (1)
    {
        cli_size = sizeof(cli_addr);
        if ((client_sock = accept(sock, (struct sockaddr *)&cli_addr,
                                  &cli_size)) == -1)
        {
            close(sock);
            fprintf(stderr, "Error accepting connection.\n");
            write_errorlog(addr, strerror(errno));
            return EXIT_FAILURE;
        }

        readret = 0;
        while ((readret = recv(client_sock, buf, BUF_SIZE, 0)) >= 1)
        {
            Request *a;

            a = parse(buf, BUF_SIZE, 1);

            if (a == NULL || readret > 8192)
            {
                memset(buf, 0, BUF_SIZE);
                strcpy(buf, "HTTP/1.1 400 Bad request\r\n\r\n");
                write_accesslog(addr, 400, a);
                readret = strlen(buf);
                if (send(client_sock, buf, readret, 0) != readret)
                {
                    close_socket(client_sock);
                    close_socket(sock);
                    fprintf(stderr, "Error sending to client.\n");
                    write_errorlog(addr, strerror(errno));
                    return EXIT_FAILURE;
                }
                memset(buf, 0, BUF_SIZE);
            }
            else if (strcmp(a->http_version, "HTTP/1.1"))
            {
                memset(buf, 0, BUF_SIZE);
                strcpy(buf, "HTTP/1.1 505 HTTP Version not supported\r\n\r\n");
                write_accesslog(addr, 505, a);
                readret = strlen(buf);
                if (send(client_sock, buf, readret, 0) != readret)
                {
                    close_socket(client_sock);
                    close_socket(sock);
                    fprintf(stderr, "Error sending to client.\n");
                    write_errorlog(addr, strerror(errno));
                    return EXIT_FAILURE;
                }
                memset(buf, 0, BUF_SIZE);
            }
            else if (!strcmp(a->http_method, "GET") || !strcmp(a->http_method, "HEAD"))
            {

                response(buf, readret, a, sock, client_sock);
                memset(buf, 0, BUF_SIZE);
            }
            else if (!strcmp(a->http_method, "POST"))
            {
                write_accesslog(addr, 200, a);
                if (send(client_sock, buf, readret, 0) != readret)
                {
                    close_socket(client_sock);
                    close_socket(sock);
                    fprintf(stderr, "Error sending to client.\n");
                    write_errorlog(addr, strerror(errno));
                    return EXIT_FAILURE;
                }
                memset(buf, 0, BUF_SIZE);
            }
            else
            {
                memset(buf, 0, BUF_SIZE);
                strcpy(buf, "HTTP/1.1 501 Not Implemented\r\n\r\n");
                write_accesslog(addr, 501, a);
                readret = strlen(buf);
                if (send(client_sock, buf, readret, 0) != readret)
                {
                    close_socket(client_sock);
                    close_socket(sock);
                    fprintf(stderr, "Error sending to client.\n");
                    write_errorlog(addr, strerror(errno));
                    return EXIT_FAILURE;
                }
                memset(buf, 0, BUF_SIZE);
            }
            memset(buf,0, BUF_SIZE);
        }

        if (readret == -1)
        {
            close_socket(client_sock);
            close_socket(sock);
            fprintf(stderr, "Error reading from client socket.\n");
            write_errorlog(addr, strerror(errno));
            return EXIT_FAILURE;
        }

        if (close_socket(client_sock))
        {
            close_socket(sock);
            fprintf(stderr, "Error closing client socket.\n");
            write_errorlog(addr, strerror(errno));
            return EXIT_FAILURE;
        }
    }
    fclose(errorlog);
    fclose(accesslog);
    close_socket(sock);

    return EXIT_SUCCESS;
}
